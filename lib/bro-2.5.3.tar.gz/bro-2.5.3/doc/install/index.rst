
.. _installation:

============
Installation
============

.. toctree::
   :maxdepth: 2

   install
   upgrade
